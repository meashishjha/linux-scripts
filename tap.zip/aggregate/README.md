# Aggregator Marketplace
 - FastAPI 
Core features includes:
  - NLP Search
  - Product Views
  - Reporting





### Technologies
Open source powered technology stack are as follows:
* [FastAPI](https://fastapi.tiangolo.com/) - Modern, fast (high-performance), web framework for building APIs with Python 3.6+ based on standard Python type hints


### Installation
Aggegator Microservices requires [Python3.10](https://www.python.org/) to run.



```sh
$ uvicorn app.main:app
```


