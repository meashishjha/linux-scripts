import time
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from app.api.routes.router import api_router
from app.settings import (APP_NAME, APP_VERSION, IS_DEBUG)
from app.utils.log import logger


logger = logger.get_default_logger(__name__)

description = """
Aggregator Marketplace 🚀
## Major Features
Backend API features:
* **NLP Search** .
* **Product Views** .
* **Reporting** .
"""

tags_metadata = [
    {
        "name": "Monitoring",
        "description": "Monitoring/Reporting related endpoints are listed here",
    },
    {
        "name": "Application",
        "description": "Application specific endpoints are listed here.",
    }
]


def get_app() -> FastAPI:
    fast_app = FastAPI(title=APP_NAME, version=APP_VERSION, debug=IS_DEBUG,
                       description=description,
                       summary="Aggregator Marketplace",
                       terms_of_service="https://wellsfargo.net",
                       contact={
                           "name": "DevRel",
                           "url": "https://wellsfargo.net",
                           "email": "kalpnath.kushwaha@wellsfargo.com",
                       },
                       openapi_tags=tags_metadata, default_response_class=JSONResponse)

    fast_app.include_router(api_router)
    return fast_app


app = get_app()



@app.middleware("http")
async def before_after_request(request: Request, call_next):
    start_time = time.time()
    request.state.new_time = "New Time"
    response = await call_next(request)
    process_time = time.time() - start_time
    logger.info("Request Execution Time = [ {} ] ".format(process_time))
    return response
