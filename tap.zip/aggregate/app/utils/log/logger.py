import logging
from io import StringIO
from logging import StreamHandler
from datetime import datetime
from pytz import timezone
from app import settings


def init(name):
    out = StringIO()
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    stdout = StreamHandler(out)
    stdout.setLevel(logging.DEBUG)
    formatter = logging.Formatter("[%(asctime)s] [%(levelname)s] [%(name)30s(%(lineno)d)]: %(message)s")
    stdout.setFormatter(formatter)
    logger.addHandler(stdout)
    return logger, out


def get_default_logger(name, **kwargs):
    logging.Formatter.converter = lambda *args: datetime.now(tz=timezone("Asia/Kolkata")).timetuple()
    formatter = "[%(asctime)s] [%(levelname)s] [Thread-%(thread)d] [%(name)s] [%(filename)s(%(lineno)d)]: %(message)s"
    logging.basicConfig(level=logging.INFO, format=formatter, datefmt="%Y-%m-%d %H:%M:%S")
    logger = logging.getLogger(name)
    logger = logging.LoggerAdapter(logger=logger, extra=kwargs)

    return logger

