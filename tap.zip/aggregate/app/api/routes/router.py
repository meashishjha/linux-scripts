from fastapi import APIRouter
from app.api.routes import home
from app.api.routes import search



api_router = APIRouter()

api_router.include_router(home.router, tags=["Monitoring"], prefix="/v1/sre")
api_router.include_router(search.router, tags=["Application"], prefix="/v1/app")
