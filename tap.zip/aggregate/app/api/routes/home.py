from fastapi import APIRouter, Response
from app.models.home import HeartBeat
from app.settings import APP_VERSION, APP_NAME

router = APIRouter()


@router.get("/", name="Home", response_description="Successful HTML Response")
def get_home():
    home_response = "<!DOCTYPE html><html>" \
                        + f"<body><p><h2 align='center'>&#x1f4a1; {APP_NAME} <sup><small>v{APP_VERSION}</small></sup> &#x1f4a1;" \
                        + f"</h2></p><p> <center>API WORKING </center>" \
                        + "</p></body></html>"
    return Response(content=home_response, media_type="text/html")


@router.get("/heartbeat", response_model=HeartBeat, name="API Status")
def get_heartbeat() -> HeartBeat:
    heartbeat = HeartBeat(is_alive=True)
    return heartbeat


@router.get("/reports", response_model=HeartBeat, name="Reporting")
def get_heartbeat() -> HeartBeat:
    heartbeat = HeartBeat(is_alive=True)
    return heartbeat