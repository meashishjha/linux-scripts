import json

from fastapi import APIRouter, Depends, Header, Query, Request, status, Body
from fastapi.encoders import jsonable_encoder
from app.utils.log.logger import get_default_logger
from app.models.search import Serp, Product
from typing import List

router = APIRouter()


@router.get("/search", response_description="Search", status_code=status.HTTP_200_OK, response_model=Serp)
def create_user(request: Request, query: str):
    print(query)
    result = {"input": query}
    results = jsonable_encoder(result)
    return results


@router.get("/get/{pid}", response_description="View Product", status_code=status.HTTP_200_OK, response_model=Product)
def create_user(request: Request, pid: int):
    print(pid)
    product = {"name": "Product Name"}
    product_detail = jsonable_encoder(product)
    return product_detail


