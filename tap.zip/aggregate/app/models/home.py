from pydantic import BaseModel


class HeartBeat(BaseModel):
    is_alive: bool