from pydantic import BaseModel
from typing import Dict, List, Tuple, Set, Optional


class DefaultModel(BaseModel):
    resource_id: str
    account_id: str
    data: Dict
    api_key: str
    api_secret: str


class OutputModel(BaseModel):
    resource_id: str
    job_id: str


class EqlModel(BaseModel):
    data: Dict
    api_key: str
    api_secret: str
