from typing import Optional
from pydantic import BaseModel, Field

class Serp(BaseModel):
    input: str = Field(...)

class Product(BaseModel):
    name: str = Field(...)


