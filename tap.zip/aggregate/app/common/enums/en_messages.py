from app import settings as s

INFERENCE_PROCESSING_FAILED = f"{s.PRODUCT_NAME} was not able to process the question. Noted for resolution."
INFERENCE_PROCESSING_FAILED_REASON = "Triggered when code breaks or for any other error"
TIMEOUT_ERROR = "Could not fetch the data"
TIMEOUT_ERROR_REASON = "Triggered when Timeout Error"
